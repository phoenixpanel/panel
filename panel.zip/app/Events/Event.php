<?php

namespace Phoenixpanel\Events;

abstract class Event
{
}
