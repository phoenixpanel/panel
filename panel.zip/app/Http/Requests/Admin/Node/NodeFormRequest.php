<?php

namespace Phoenixpanel\Http\Requests\Admin\Node;

use Phoenixpanel\Rules\Fqdn;
use Phoenixpanel\Models\Node;
use Phoenixpanel\Http\Requests\Admin\AdminFormRequest;

class NodeFormRequest extends AdminFormRequest
{
    /**
     * Get rules to apply to data in this request.
     */
    public function rules(): array
    {
        if ($this->method() === 'PATCH') {
            return Node::getRulesForUpdate($this->route()->parameter('node'));
        }

        $data = Node::getRules();
        $data['fqdn'][] = Fqdn::make('scheme');

        return $data;
    }
}
