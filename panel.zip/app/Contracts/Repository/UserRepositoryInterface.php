<?php

namespace Phoenixpanel\Contracts\Repository;

interface UserRepositoryInterface extends RepositoryInterface
{
}
