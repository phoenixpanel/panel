<?php

namespace Phoenixpanel\Contracts\Repository;

interface ApiPermissionRepositoryInterface extends RepositoryInterface
{
}
