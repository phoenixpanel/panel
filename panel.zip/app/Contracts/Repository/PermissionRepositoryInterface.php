<?php

namespace Phoenixpanel\Contracts\Repository;

interface PermissionRepositoryInterface extends RepositoryInterface
{
}
