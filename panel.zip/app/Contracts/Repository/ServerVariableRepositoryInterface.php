<?php

namespace Phoenixpanel\Contracts\Repository;

interface ServerVariableRepositoryInterface extends RepositoryInterface
{
}
