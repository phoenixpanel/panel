<?php

namespace Phoenixpanel\Exceptions;

class AutoDeploymentException extends \Exception
{
}
