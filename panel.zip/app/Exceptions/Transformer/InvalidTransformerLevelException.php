<?php

namespace Phoenixpanel\Exceptions\Transformer;

use Phoenixpanel\Exceptions\PterodactylException;

class InvalidTransformerLevelException extends PterodactylException
{
}
