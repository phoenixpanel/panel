<?php

namespace Phoenixpanel\Exceptions\Service\Server;

use Phoenixpanel\Exceptions\PterodactylException;

class RequiredVariableMissingException extends PterodactylException
{
}
