<?php

namespace Phoenixpanel\Exceptions\Service;

use Phoenixpanel\Exceptions\DisplayException;

class InvalidFileUploadException extends DisplayException
{
}
