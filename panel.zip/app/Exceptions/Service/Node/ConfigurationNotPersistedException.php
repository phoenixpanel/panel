<?php

namespace Phoenixpanel\Exceptions\Service\Node;

use Phoenixpanel\Exceptions\DisplayException;

class ConfigurationNotPersistedException extends DisplayException
{
}
