<?php

namespace Phoenixpanel\Exceptions\Service\Egg;

use Phoenixpanel\Exceptions\DisplayException;

class HasChildrenException extends DisplayException
{
}
