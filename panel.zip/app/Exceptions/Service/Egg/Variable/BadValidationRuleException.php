<?php

namespace Phoenixpanel\Exceptions\Service\Egg\Variable;

use Phoenixpanel\Exceptions\DisplayException;

class BadValidationRuleException extends DisplayException
{
}
