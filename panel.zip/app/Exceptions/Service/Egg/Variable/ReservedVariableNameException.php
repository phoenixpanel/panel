<?php

namespace Phoenixpanel\Exceptions\Service\Egg\Variable;

use Phoenixpanel\Exceptions\DisplayException;

class ReservedVariableNameException extends DisplayException
{
}
