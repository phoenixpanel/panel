<?php

namespace Phoenixpanel\Exceptions\Service\Egg;

use Phoenixpanel\Exceptions\DisplayException;

class BadJsonFormatException extends DisplayException
{
}
