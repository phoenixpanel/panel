<?php

namespace Phoenixpanel\Exceptions\Service\Egg;

use Phoenixpanel\Exceptions\DisplayException;

class NoParentConfigurationFoundException extends DisplayException
{
}
