<?php

namespace Phoenixpanel\Exceptions\Service\Helper;

class CdnVersionFetchingException extends \Exception
{
}
