<?php

namespace Phoenixpanel\Exceptions\Service\Allocation;

use Phoenixpanel\Exceptions\PterodactylException;

class AllocationDoesNotBelongToServerException extends PterodactylException
{
}
