<?php

namespace Phoenixpanel\Exceptions\Service\Allocation;

use Phoenixpanel\Exceptions\DisplayException;

class ServerUsingAllocationException extends DisplayException
{
}
