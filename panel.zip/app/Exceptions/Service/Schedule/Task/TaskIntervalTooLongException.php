<?php

namespace Phoenixpanel\Exceptions\Service\Schedule\Task;

use Phoenixpanel\Exceptions\DisplayException;

class TaskIntervalTooLongException extends DisplayException
{
}
