<?php

namespace Phoenixpanel\Exceptions\Service\Subuser;

use Phoenixpanel\Exceptions\DisplayException;

class ServerSubuserExistsException extends DisplayException
{
}
