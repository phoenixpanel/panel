<?php

namespace Phoenixpanel\Exceptions\Service\Deployment;

use Phoenixpanel\Exceptions\DisplayException;

class NoViableNodeException extends DisplayException
{
}
