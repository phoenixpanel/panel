<?php

namespace Phoenixpanel\Exceptions\Service\Deployment;

use Phoenixpanel\Exceptions\DisplayException;

class NoViableAllocationException extends DisplayException
{
}
