<?php

namespace Phoenixpanel\Exceptions\Repository;

use Phoenixpanel\Exceptions\PterodactylException;

class RepositoryException extends PterodactylException
{
}
