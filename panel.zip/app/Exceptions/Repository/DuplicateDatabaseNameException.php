<?php

namespace Phoenixpanel\Exceptions\Repository;

use Phoenixpanel\Exceptions\DisplayException;

class DuplicateDatabaseNameException extends DisplayException
{
}
