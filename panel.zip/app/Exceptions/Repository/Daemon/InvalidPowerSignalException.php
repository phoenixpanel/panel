<?php

namespace Phoenixpanel\Exceptions\Repository\Daemon;

use Phoenixpanel\Exceptions\Repository\RepositoryException;

class InvalidPowerSignalException extends RepositoryException
{
}
