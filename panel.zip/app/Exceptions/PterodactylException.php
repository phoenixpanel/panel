<?php

namespace Phoenixpanel\Exceptions;

class PterodactylException extends \Exception
{
}
