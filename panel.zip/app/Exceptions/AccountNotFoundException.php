<?php

namespace Phoenixpanel\Exceptions;

class AccountNotFoundException extends \Exception
{
}
