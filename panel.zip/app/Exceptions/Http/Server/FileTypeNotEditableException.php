<?php

namespace Phoenixpanel\Exceptions\Http\Server;

use Phoenixpanel\Exceptions\DisplayException;

class FileTypeNotEditableException extends DisplayException
{
}
