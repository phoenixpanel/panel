<?php

namespace Phoenixpanel\Exceptions\Http\Base;

use Phoenixpanel\Exceptions\DisplayException;

class InvalidPasswordProvidedException extends DisplayException
{
}
